-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema RA_DB
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `RA_DB` ;

-- -----------------------------------------------------
-- Schema RA_DB
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `RA_DB` DEFAULT CHARACTER SET utf8 ;
USE `RA_DB` ;

-- -----------------------------------------------------
-- Table `RA_DB`.`ra_users_tab`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `RA_DB`.`ra_users_tab` ;

CREATE TABLE IF NOT EXISTS `RA_DB`.`ra_users_tab` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(255) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `firstname` VARCHAR(255) NOT NULL,
  `lastname` VARCHAR(255) NOT NULL,
  `organization` VARCHAR(200) NOT NULL,
  `Salt_val` VARCHAR(128) NULL DEFAULT NULL,
  `enabled` TINYINT(1) NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE INDEX `email` (`email` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `RA_DB`.`certificate_req_tab`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `RA_DB`.`certificate_req_tab` ;

CREATE TABLE IF NOT EXISTS `RA_DB`.`certificate_req_tab` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `common_name` VARCHAR(150) NOT NULL,
  `country` VARCHAR(75) NOT NULL,
  `stateprovince` VARCHAR(150) NOT NULL,
  `locale` VARCHAR(100) NOT NULL,
  `organization` VARCHAR(200) NOT NULL,
  `organization_unit` VARCHAR(200) NOT NULL,
  `date` DATE NOT NULL,
  `csr_file` BLOB NOT NULL,
  `cer_serial_number` VARCHAR(150) NULL DEFAULT NULL,
  `certificate` BLOB NULL DEFAULT NULL,
  `user_id` INT(11) NOT NULL,
  PRIMARY KEY (`common_name`, `country`, `stateprovince`, `organization`, `locale`, `organization_unit`),
  INDEX `fk_certificate_req_tab_1_idx` (`user_id` ASC),
  KEY (`id`),
  CONSTRAINT `fk_certificate_req_tab_1`
    FOREIGN KEY (`user_id`)
    REFERENCES `RA_DB`.`ra_users_tab` (`id`)
    ON DELETE RESTRICT
    ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
